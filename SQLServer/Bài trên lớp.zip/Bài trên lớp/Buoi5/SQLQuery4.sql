PRINT dbo.CongHaiSo(2,3)
SELECT dbo.HienThiTien(CarId) , Color FROM Car

SELECT CAST(CarId AS varchar) + 'DOLAR', Color FROM Car
