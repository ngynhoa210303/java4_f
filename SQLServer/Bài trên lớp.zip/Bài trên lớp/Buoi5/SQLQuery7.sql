CREATE VIEW CarDongCoXang
AS
	SELECT * FROM Car WHERE Engine = 'Dong co xang'

SELECT * FROM CarDongCoXang